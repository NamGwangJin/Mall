CREATE DATABASE  IF NOT EXISTS `shop` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `shop`;
-- MySQL dump 10.13  Distrib 8.0.33, for Win64 (x86_64)
--
-- Host: 127.168.0.16    Database: shop
-- ------------------------------------------------------
-- Server version	8.0.33

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `prod_id` int NOT NULL AUTO_INCREMENT,
  `prod_name` varchar(32) NOT NULL,
  `prod_price` int NOT NULL,
  `prod_msg` varchar(1000) NOT NULL,
  `prod_img` varchar(100) NOT NULL,
  `prod_update` datetime DEFAULT NULL,
  PRIMARY KEY (`prod_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'Mini Photo Card',8000,'미니 포토카드 입니다.','product1','2023-08-23 17:12:27'),(2,'Mini Photo Card Set',80000,'포토카드 세트 입니다.','product2','2023-08-23 17:26:18'),(3,'Photo Card Binder',32000,'포토카드 바인더 입니다.','product3','2023-08-23 17:27:26'),(4,'Premium Photo',11000,'프리미엄 포토카드 입니다.','product4','2023-08-23 17:28:19'),(5,'Image Picket',10000,'Image Picket.','product5','2023-08-23 17:29:42'),(6,'Acrylic Stand',20000,'Acrylic Stand.','product6','2023-08-23 17:30:09'),(7,'Lucky Draw',9000,'Lucky Draw.','product7','2023-08-23 17:30:34'),(8,'Postcard Book',22000,'Postcard Book.','product8','2023-08-23 17:31:04'),(9,'Photo Deco Pack',22000,'Photo Deco Pack.','product9','2023-08-23 17:31:34'),(10,'Keyring',20000,'Keyring.','product10','2023-08-23 17:32:03'),(11,'Badge Set',22000,'Badge Set.','product11','2023-08-23 17:32:27'),(12,'Luggage Tag',20000,'Luggage Tag.','product12','2023-08-23 17:32:48');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-08-25 17:44:54
