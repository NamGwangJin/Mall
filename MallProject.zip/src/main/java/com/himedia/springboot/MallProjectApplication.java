package com.himedia.springboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MallProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(MallProjectApplication.class, args);
	}

}
